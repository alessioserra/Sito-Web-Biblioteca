<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]=0; 
	
    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;		
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head>
<title> Redirect</title>
<!--icona -->
<link rel="shortcut icon" type="image/png" href="icona.png"/>
<meta charset="utf-8">
<meta name="author" content="Alessio Serra"> 

<?php
if ( $_SESSION["precedente"]==="login" ) {
//Ottengo variabili
$user = $_REQUEST["username"];
$pass = $_REQUEST["password"];

//Inizializzo variabile che mi dirà se l'utente ha i permessi per loggarsi oppure no
$login = false;

//Verifico che rispettino le regex
if ( preg_match("/^([A-Za-z]|%){1}(\w|%){2,5}$/",$user) && preg_match("/^[A-Za-z]{4,8}$/",$pass) ) {

error_reporting(0);
//Apro connessione DB
$con = mysqli_connect( "localhost" , "uReadOnly" , "posso_solo_leggere", "biblioteca" );
 
//Se la connesione è fallita stampo errore e rindirizzo alla pagina
if ( mysqli_connect_errno() ) {
		   $_SESSION["erroreLogin"]="Errore - collegamento al DB impossibile: ".mysqli_connect_errno(); 
       header("Location:login.php");
       exit();
}

//Se la connessione è riuscita:
else {

//Selezione coppie di username e password
$query = "SELECT username, pwd FROM users";
//Eseguo query
$result = mysqli_query($con,$query);

//Analizzo risultato
while ( $res = mysqli_fetch_assoc($result) ){
        
		//Verifico corrispondenza user e pass
		if ($res["username"]===$user && $res["pwd"]===$pass){
			
			//Se trovo la coppia di valori user e pass corretti,
			//posso cominciare il login
			$login = true;
		}
}

//Posso eliminare i risultati, non mi servono più		
mysqli_free_result($result);

}

//Se il login è true, posso aprire la sessione di Login
if ($login===true){
	
	//Setto username nella session
	$_SESSION["user"] = $user;
	//Setto login come vero
	$_SESSION["login"]=true;
	
	//Trovo numero di libri
	$sql2 = "SELECT COUNT(*) AS libri FROM books WHERE prestito=?";
	
	//Prepared statement
	$stmt = mysqli_prepare($con, $sql2);
    mysqli_stmt_bind_param($stmt, "s", $user);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_bind_result($stmt, $libri);
	mysqli_stmt_fetch($stmt);
	$_SESSION["libri"] = $libri;
	
	//Elimino risultati e chiudo connessione		
    mysqli_stmt_free_result($stmt);
	mysqli_close($con);
	
	//Setto il cookie relativo all'user per 48h
	setcookie("user",$user,time()+48*3600);
	
	//Re-indirizzo a pagina LIBRI
	header("Location:libri.php");
	exit();
}
//Altrimenti torno alla pagina di login
else { mysqli_stmt_free_result($stmt);
	   mysqli_close($con);
	   
	   $_SESSION["erroreLogin"]="Username e/o Password errati.";
	   
       header("Location:login.php");
       exit();
     }		
}
//Se non rispettano le regex, rimando subito a pagina di errore
else { $_SESSION["erroreLogin"]="Username e/o Password errati.";
       header("Location:login.php");
       exit();
	 }
} else header("Location:error.php");
?>
</body>
</html>