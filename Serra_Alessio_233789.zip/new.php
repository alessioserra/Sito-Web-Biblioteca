﻿<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]= 0;   

    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;

	if (!isset($_SESSION["precedente"]))
		$_SESSION["precedente"]="new";	

    //Includo foglio delle funzioni
    include("function.inc");	
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("New") ?>
</head>

<script>
function alert1(){
window.alert("Lo username  puo' contenere solo caratteri alfabetici o numerici o il simbolo %, deve iniziare con un carattere alfabetico o con %, deve essere lungo da un minimo di tre ad un massimo di sei caratteri e deve contenere almeno un carattere non numerico ed uno numerico.");
}

function alert2(){
window.alert("La password puo' contenere solo caratteri alfabetici, deve essere lunga minimo quattro e massimo otto caratteri ed avere almeno un carattere minuscolo ed uno maiuscolo.");
}

function checkPassword(){
pass1 = document.getElementById("p").value;
pass2 = document.getElementById("pass2").value;

if (pass1!=pass2){
	document.getElementById("error").innerHTML=("Password inserite diverse!");
	document.getElementById("error").style.color="red";
    }
	else{
	document.getElementById("error").innerHTML=("Password inserite uguali");
	document.getElementById("error").style.color="green";	
	}
	
	if ( pass1=="" || pass2=="" ) document.getElementById("error").innerHTML=("");
}

function regex() {

var e1= /^([A-Za-z]|%){1}(\w|%){2,5}$/ ; //USER
var e2= /^[A-Za-z]{4,8}$/ ; //PASS
var e3=/\d/; //USER
var e4=/[a-zA-Z%]/; //USER
var e5=/[a-z]/; //PASS
var e6=/[A-Z]/; //PASS

var user = document.getElementById("u").value;
var psw = document.getElementById("p").value;

if ( (e1.test(user)) && (e2.test(psw)) && (e3.test(user)) && (e4.test(user)) && (e5.test(psw)) && (e6.test(psw)) ){
	document.getElementById("but").disabled=false;
    }
else{ document.getElementById("but").disabled=true;}

}
</script>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="libri.php">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="#" class="active">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<?php $_SESSION["precedente"]="new"; ?>
<h1> Nuovo Utente </h1>

<p>Scegliere username e password, confermare la password e premere su REGISTRAMI per completare la registrazione.</p>

<form name="login" action="result.php" method="POST">                                                     
<p class="log">Username  <input class="text" type="text" name="username" id="u" value="" oninput="regex()"> <img class="info" src="info.png" onclick="alert1()"></p>
<p class="log">Password  <input class="text" type="password" name="pass1" id="p" value="" oninput="regex()"> <img class="info" src="info.png" onclick="alert2()"></p>
<p class="log">Conferma  <input class="text" type="password" name="pass2" id="pass2" value="" oninput="checkPassword()"> <span class="error" id="error"></span> </p>
<p>
<input id="but" class="button" type="submit" value="REGISTRAMI">
</p>
</form>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>