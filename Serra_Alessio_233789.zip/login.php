<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]=0;
	
	if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;

    if (!isset($_SESSION["precedente"]))
        $_SESSION["precedente"]="login";	
	
	//Includo foglio delle funzioni
    include("function.inc");
	
}
?>   	
<!DOCTYPE HTML>
<html lang = "it">

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("Login") ?>
</head>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="libri.php">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?> class="active">Login</a>
  <a href="new.php">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<h1> Login </h1>

<?php 

if ($_SESSION["login"]===false){

//Tengo d'occhio pagina precedente	
$_SESSION["precedente"]="login";
	
echo "<img src='login.png' alt='loginPic'>
<form name='login' action='redirect.php' method='POST'>                                         <!-- Se esiste setto il cookie-->
<p class='log'>Username  <input class='text' type='text' id='user' name='username' value=";?> <?php if ( isset($_COOKIE["user"]) ) {
                                                                               echo $_COOKIE['user'];}
														                       else echo "";?><?php echo"></p>
<p class='log'>Password  <input class='text' type='password' id='pass' name='password' value=''></p>
<p><input class='button' type='button' value='Pulisci' onclick=\" username.value='', password.value='' \">
   <input class='button' type='submit' value='OK'>
</p>
<h2>";?><?php if (!isset($_SESSION['erroreLogin'])) echo "&nbsp";
          else {
			  echo $_SESSION["erroreLogin"]; 
			  $_SESSION["erroreLogin"]="&nbsp";
		       }?><?php echo"</h2>
</form>";
}
else echo "<p>Non puoi effettuare il login se sei gi&agrave connesso!</p>";
?>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>