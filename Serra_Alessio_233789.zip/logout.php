<?php 
//Default 
$session = true;

if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    session_start();
//
	
	//Logout
		//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]=0;   

    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;
	
		if (!isset($_SESSION["precedente"]))
		$_SESSION["precedente"]="logout";
	
	//Includo foglio delle funzioni
    include("function.inc");
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("Logout") ?>
</head>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<?php 
//Caso in cui accedo alla pagina di Logout in modo 'non convenzionale'
if ($_SESSION["login"]===false) {
	echo "<p>Per poter effetturare un logout occorre prima effettuare il <a href='login.php'>Login</a>!</p>";
    $_SESSION["precedente"]="logout";
}
//Disconnessione
else{
	
	//Chiudo sessione
	session_destroy();
	$_SESSION = array();
	
	//Inizializzo variabili
	$_SESSION["user"]="ANONIMO";
	$_SESSION["login"]=false;
	$_SESSION["libri"]=0;
	
	//Cancello il cookie
	$params = session_get_cookie_params();
	setcookie( session_name(), '' , time()-42000 ,$params["path"],$params["domain"],$params["secure"],$params["httponly"] );

    echo "<h1> Logout </h1>";
    echo "<p>Logout avvenuto con successo!</p>";
    echo "<p>Navigherai adesso in modalit&agrave anonima.</p>";
	$_SESSION["precedente"]="logout";
    }
?>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore menu' -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="libri.php">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="new.php">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?> class="active">Logout</a>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>
