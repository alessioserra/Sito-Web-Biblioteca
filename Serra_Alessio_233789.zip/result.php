<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]=0;
	
	if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;	
	
	//Includo foglio delle funzioni
    include("function.inc");
}
?>  
<!DOCTYPE HTML>
<html lang = "it">

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("New") ?>
</head>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="libri.php">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="new.php" class="active">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">

<?php 

if ( $_SESSION["precedente"]==="new" ) {

error_reporting(0);
//Apro connessione DB
$con = mysqli_connect( "localhost" , "uReadWrite" , "SuperPippo!!!", "biblioteca" );
 
//Se la connesione è fallita stampo errore
if ( mysqli_connect_errno() ) {
	printf ("<p>Errore - collegamento al DB impossibile: %s </p>\n" , mysqli_connect_errno());
}

//Se la connessione è riuscita:
else {

$username = $_REQUEST["username"];
$pass1 = $_REQUEST["pass1"];
$pass2 = $_REQUEST["pass2"];

if ( preg_match("/^([A-Za-z]|%){1}(\w|%){2,5}$/",$username) && preg_match("/^[A-Za-z]{4,8}$/",$pass1) 
  && preg_match("/\d/",$username) && preg_match("/[a-zA-Z%]/",$username) && preg_match("/[a-z]/",$pass1) 
  && preg_match("/[A-Z]/",$pass1) && ($pass1===$pass2) ){
	
$query = "SELECT username FROM users";

//Eseguo query
$result = mysqli_query($con,$query);
	

while ( $res = mysqli_fetch_assoc($result) ){
        
		if ($res["username"]===$username){
			echo "<h1>ERRORE!!!</h1><p>ERRORE, l'username esiste gi&agrave!</p>";
			//Libero memoria
            mysqli_free_result($result);
	        //Chiudo connessione
            mysqli_close($con);	
			
			return; //esco fuori dal PHP
            }
}	
mysqli_free_result($result);

//Se sono arrivato fin qui, posso procedere alla registrazione
$sql = "INSERT INTO users (username,pwd) VALUES (?,?)";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "ss", $username, $pass1);
$res = mysqli_stmt_execute($stmt);

if ($res==null){ echo "<h1>ERRORE!!!</h1><p>ERRORE, inserimento nel database fallito!</p>"; }
else { echo "<h1>Operazione Completata</h1><p>Registrazione andata a buon fine. Puoi adesso usare i tuoi dati per loggarti nel sito!</p>";}

}else { echo "<h1>ERRORE!!!</h1><p>ERRORE, username o password non idonee!</p>"; }

//Chiudo tutto
mysqli_stmt_free_result($stmt);
mysqli_close($con);
}

} else header("Location:error.php");
?>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>