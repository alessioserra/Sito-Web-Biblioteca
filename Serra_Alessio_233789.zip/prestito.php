<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]= 0;   

    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;	
	
	//Includo foglio delle funzioni
    include("function.inc");
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("Libri") ?>
</head>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="libri.php" class="active">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="new.php">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<h1>Libri</h1>
<?php
if ( $_SESSION["precedente"]==="libri" ){

if ( $_SESSION["login"]===true ){

       //Conto il numero di parametri passati dalla URI
       $count = substr_count($_SERVER['REQUEST_URI'],"=");

if ( isset($_REQUEST["giorni"]) ){ //Controllo che esista la variabile dei giorni
	if ( $_REQUEST["giorni"]>0 ){ //Regex sui giorni
		
		//Creo array vuoto
		$idLibri = array();
	    //Ciclo sull'array
		foreach ( $_SESSION["prestiti"] as $chiave => $valore ){
			//Se è stato selezionato tramite checkbox
			if( isset($_REQUEST[$valore]) ) array_push($idLibri, $valore); //Aggiungo valore all'array
		}
		
			//Controllo tutte le riuscite delle query:
			$count=0;
		
		if (sizeof($idLibri)===0) echo "<p>Nessun libro selezionato per il prestito.<br>Torna indietro e riprova.</p>";
		
		else{
		if ( (sizeof($idLibri)+($_SESSION["libri"])) < 4 ){ //Controllo sul limite di libri in prestito
			
			error_reporting(0);
			//Apro connessione DB
            $con = mysqli_connect( "localhost" , "uReadWrite" , "SuperPippo!!!", "biblioteca" );
            //Se la connesione è fallita stampo errore
            if ( mysqli_connect_errno() ) {
      	    printf ("<p>Errore - collegamento al DB impossibile: %s </p>\n" , mysqli_connect_errno());
            }
            //Se la connessione è riuscita:
            else { 	
			
			//Utente , durata, data
			$user = $_SESSION["user"];
			$giorno = $_REQUEST["giorni"];
			$date =date("Y-m-d H:m:s");
			
			//Preparo la query standard per l'UPDATE
	        $update = "UPDATE books SET data=?, prestito=?, giorni=? WHERE id=?";
			$stmt = mysqli_prepare($con, $update);
			
			//Ciclo per ogni ID dei libri passati come parametro
			foreach ($idLibri as $id ) {
				
            $stmt = mysqli_prepare($con, $update);
            mysqli_stmt_bind_param($stmt, "ssii", $date, $user, $giorno, $id);
	        $res = mysqli_stmt_execute($stmt);
			
			//Controllo che la query sia andata bene
			if ( $res != null ) $count = $count + 1;
			
			//Libero memoria per l'iterazione successiva
			mysqli_stmt_free_result($stmt);	
			
			}

			//Chiudo connessione
			mysqli_close($con);
			
			if ($count === sizeof($idLibri) ){
				echo "Operazione di presa in prestito riuscita!<br>";
				//Aggiorno contatore libri dell'utente
				$_SESSION["libri"]=(($_SESSION["libri"])+($count));
				echo "Torna alla pagina <a href='libri.php'>libri</a> per verificarne lo stato";
			
			    }else echo "Errore durante l'operazione di presa in prestito!<br>Torna indietro e riprova.";
			}				
		}else echo "Non &egrave possibile avere in prestito pi&ugrave di 3 libri!";
	  }
	}
	else echo "Errore nel formato del numero di giorni!";
}else echo "Numero di giorni della durata del prestito non inserito!";
}else echo "<p>Effettua il <a href=\"login.php\">login</a> per poter gestire i tuoi libri!</p>";

}else header("Location:error.php");
?>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>