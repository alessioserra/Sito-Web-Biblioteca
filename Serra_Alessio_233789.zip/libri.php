﻿<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]= 0;   

    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;	

    $_SESSION["identificativi"]=array();
	$_SESSION["prestiti"]=array();
	
	//Includo foglio delle funzioni
    include("function.inc");
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head>
<script type="text/javascript" src="script.js"></script>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("Libri") ?>
</head>

<script>
function controllo(){

var e=/^[0-9]*$/;
var giorni = document.getElementById("g").value;

if (e.test(giorni)) {
	 document.getElementById("prestito").disabled=false;
     }
else {
	 document.getElementById("prestito").disabled=true;
     }
}
</script>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="#" class="active">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="new.php">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<h1>Libri</h1>
<?php
if ( $_SESSION["login"]===true ){
	
//Tengo d'occhio la pagia precedente
$_SESSION["precedente"]="libri";
	
//Apro connessione DB
error_reporting(0);
$con = mysqli_connect( "localhost" , "uReadOnly" , "posso_solo_leggere", "biblioteca" );
 
//Se la connesione è fallita stampo errore
if ( mysqli_connect_errno() ) {
	printf ("<p>Errore - collegamento al DB impossibile: %s </p>\n" , mysqli_connect_errno());
}
//Se la connessione è riuscita:
else {	
	//Trovo numero di libri
	$query = "SELECT titolo,autori,id FROM books WHERE prestito=?";
	
	//Prepared statement
	$user = $_SESSION["user"];
	
	$stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "s", $user);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_bind_result($stmt, $titolo, $autore, $id);
	
	//Stampo la tabella 
	echo "<h2>Libri posseduti</h1>";
	
	if ( $_SESSION["libri"]>0 ){
	
	//Inizio form
	echo "<form name=\"restituisci\" action=\"reso.php\" method=\"POST\">";
	echo "<table><tr><th>Titolo</th><th>Autore</th><th>Reso</th></tr>";
	
    while ( mysqli_stmt_fetch($stmt) ){
          echo "<tr><td>".$titolo."</td><td>".$autore."</td><td><input class='rest' type=\"submit\" name=$id value=\"RESTITUISCI \"></td></tr>";
		  $_SESSION["identificativi"][$id] = $id;
	}
	echo "</table>";
	echo "</form>";
	
	}else {
		echo "<p>Nessun libro posseduto dall'utente</p>";
		mysqli_stmt_free_result($stmt);
	    }
		
	//Tutti i libri della biblioteca
	$query2 = "SELECT * FROM books";
	
	//Eseguo query
    $result = mysqli_query($con,$query2);
	
	//Stampo la tabella 
	echo "<h2>Libri della biblioteca</h1>";
	echo "<form name='f' action='prestito.php' method='POST'>"; //Tasto prestito rimanda ad una pagina di conferma
	echo "<table><tr><th>Titolo</th><th>Autore</th><th>Stato</th></tr>";
	
	//FUNZIONAMA BISOGNA TOGLIERE I WARNING
    while ( $res = mysqli_fetch_assoc($result) ){
       
	   //Data del prestito
	   $datainizio = date("Y-m-d",strtotime($res["data"]));
	   //Durata del prestito stabilito
	   $durata = $res["giorni"];
	   //Data del controllo
	   $datafine = date("Y-m-d");

       $data_1 = explode("-", $datainizio);
       $data_2 = explode("-", $datafine);
       $inizio = intval(gregoriantojd( $data_1[1], $data_1[2], intval($data_1[0]) ));
       $fine = intval(gregoriantojd( $data_2[1], $data_2[2], intval($data_2[0]) ));
        
	   $intervallo = $fine - $inizio;
	   
	  if ( ($res["prestito"]!="") && ($intervallo>$durata) ) echo "<tr><td>".$res["titolo"]."</td><td>".$res["autori"]."</td><td>PRESTITO SCADUTO</td></tr>";
	  else if ($res["prestito"]==""){
		  echo "<tr><td>".$res["titolo"]."</td><td>".$res["autori"]."</td><td><input type=\"checkbox\" name='".$res["id"]."' value='".$res["id"]."'></td></tr>";
	      //Lo aggiungo alla sessione degli id
		  $_SESSION["prestiti"][$res["id"]] = $res["id"] ;
	  }
	  else if ($res["prestito"]!="") echo "<tr><td>".$res["titolo"]."</td><td>".$res["autori"]."</td><td>IN PRESTITO</td></tr>";
	  
	}
	echo "</table>";
	echo "<p class='log'>Numero di giorni <input class='text' type=\"number\" style='width:8ex;' id=\"g\" name=\"giorni\" value=\"\" oninput=\"controllo()\"> <input class='button' id=\"prestito\" type=\"submit\" value=\"PRESTITO\"></p>";
	echo "</form>";
	
	//Chiudo tutto
	mysqli_free_result($result);
	mysqli_close($con);
}

//Se l'utente NON e' loggato
}else{ 
error_reporting(0);
$con = mysqli_connect( "localhost" , "uReadOnly" , "posso_solo_leggere", "biblioteca" );
 
//Se la connesione è fallita stampo errore
if ( mysqli_connect_errno() ) {
	printf ("<p>Errore - collegamento al DB impossibile: %s </p>\n" , mysqli_connect_errno());
}
//Se la connessione è riuscita:
else {
	
	//Trovo numero di libri totali
	$query1 = "SELECT COUNT(*) as cnt FROM books";
	$totali = mysqli_query($con,$query1);
	 while ( $res = mysqli_fetch_assoc($totali) ){
		 echo "<p>Numero di libri totali: ".$res["cnt"]."</p>";
	 }
	
	mysqli_free_result($totali);
	
	//Trovo numero di libri disponibili
	$query2 = "SELECT COUNT(*) FROM books WHERE prestito=?";
	
	//In prestito da nessuno ("")
	$none = "";
	
	$stmt = mysqli_prepare($con, $query2);
    mysqli_stmt_bind_param($stmt, "s", $none);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_bind_result($stmt, $disponibili);
	
    while ( mysqli_stmt_fetch($stmt) ){
          echo "<p>Numero di libri disponibili: ".$disponibili."</p>";
	}
	echo "<p>Effettua il <a href=\"login.php\">login</a> per poter prendere in prestito dei libri!";
	
	mysqli_stmt_free_result($stmt);
	
	mysqli_close($con);
}
}
?>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>