<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]=0;   

    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;	
	
	if (!isset($_SESSION["precedente"]))
		$_SESSION["precedente"]="home";

    //Includo foglio delle funzioni
    include("function.inc");	
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head> <!-- Modalità per smartphone -->
<meta name='viewport' content='width=device-width, initial-scale=1.0, min-scale=1.0'>
<?php head("Home")?>
</head>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status()?></p>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="#"class="active">Home</a>
  <a href="libri.php">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="new.php">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<?php $_SESSION["precedente"]="home"; ?>
<h1> Home </h1>
<p>Benvenuto in BookPoliTO!</p>
<p>Questo sito web &egrave stato realizzato per permettere di verificare lo stato dei tuoi libri
e, in caso, modificarlo a tuo piacimento e secondo le tue esigenze...
perch&egrave ricorda che i clienti sono sempre importanti per noi! <br></p>
<img src="home.png" alt="homePic">
<!-- inserire qualcosa -->
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer()?>
</footer>
</div>

</div>
</body>
</html>