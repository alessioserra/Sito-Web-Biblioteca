<?php 
$session = true;
    //stato sessone    =  disabilitata
if ( session_status() === PHP_SESSION_DISABLED ){
	$session = false;
}
         //Se non vi è una sessione attiva 
elseif ( session_status() != PHP_SESSION_ACTIVE ){
	
    //crea sessione
    session_start();
	
	//Inizializzo a 0 le variabili
    if (!isset($_SESSION["user"]))
		$_SESSION["user"]="ANONIMO";
	
	if (!isset($_SESSION["libri"]))
		$_SESSION["libri"]= 0;   

    if (!isset($_SESSION["login"]))
        $_SESSION["login"]=false;	

    if (!isset($_SESSION["id"]))
        $_SESSION["idL"]=0;	
	
	//Includo foglio delle funzioni
    include("function.inc");
}
?>
<!DOCTYPE HTML>
<html lang = "it">

<head>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<?php head("Libri") ?>
</head>

<!-- contenitore esterno -->
<div class="container">
<body>

<!--contenitore header -->
<div class="header">
<header>BookPoliTO</header>
</div>

<!-- contenitore menu' (Da sistemare) -->
<div class="menu">
<p class="menu">Menu</p>
  <a href="home.php">Home</a>
  <a href="libri.php" class="active">Libri</a>
  <a href=<?php if ( $_SESSION["login"]===true) echo "#";
                else echo "\"login.php\"";?>>Login</a>
  <a href="new.php">New</a>
  <a href=<?php if ( $_SESSION["login"]===false) echo "#";
                else echo "\"logout.php\"";?>>Logout</a>
</div>

<!-- contenitore contenuto principale -->
<div class="contenuto">
<h1> Restituzione </h1>
<?php
if ( $_SESSION["precedente"]==="libri" ){

//Sessione deve essere attiva
if ( $session===true ){
	
//Posso restituire MASSIMO 1 libro per volta
$count = substr_count($_SERVER['REQUEST_URI'],"=");
if ($count<=1){

//Scorro i valori del'array 
foreach($_SESSION["identificativi"] as $chiave => $valore){
//Quando trovo il valore relativo al bottone "Restituisci" cliccato
if(isset($_REQUEST[$chiave]))
$_SESSION["idL"] = $valore; //Lo assegno alla sessione corrente
}

$id = $_SESSION["idL"];
//Dopo averlo assegnato, lo rinizializzo
$_SESSION["idL"] = 0;

error_reporting(0);
//Apro connessione DB
$con = mysqli_connect( "localhost" , "uReadWrite" , "SuperPippo!!!", "biblioteca" );
 
//Se la connesione è fallita stampo errore
if ( mysqli_connect_errno() ) {
	printf ("<p>Errore - collegamento al DB impossibile: %s </p>\n" , mysqli_connect_errno());
}
//Se la connessione è riuscita:
else {	
	//Verifico che il libro esista O sia posseduto da quell'utente
	$query = "SELECT data FROM books WHERE id=? AND prestito=?";
	$durataPrestito = 0;
	
	//Prepared statement
	
	$stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "is", $id, $_SESSION["user"]);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_bind_result($stmt,$data);
	
	
	//Libro esistente e posseduto dall'utente
	if ( mysqli_stmt_fetch($stmt) ){
          
	//Data del prestito
	$datainizio = date("Y-m-d",strtotime($data));
	//Data della restituzione
	$datafine = date("Y-m-d");

	//Calcolo durata del prestito
    $data_1 = explode("-", $datainizio);
    $data_2 = explode("-", $datafine);
    $inizio = intval(gregoriantojd( $data_1[1], $data_1[2], intval($data_1[0]) ));
    $fine = intval(gregoriantojd( $data_2[1], $data_2[2], intval($data_2[0]) ));    
	$durataPrestito = $fine - $inizio;
	
	mysqli_stmt_free_result($stmt);
	
	$query2 ="UPDATE books SET prestito='', giorni=0 , data='0000-00-00 00:00:0' WHERE id=?";
	
    $stmt = mysqli_prepare($con, $query2);
    mysqli_stmt_bind_param($stmt, "i", $id);
	$res = mysqli_stmt_execute($stmt);
	
	if ($res!=null){
		//Stampo messaggio di successo
		echo "<p>Libro Restituito!<br>La durata del prestito &egrave stata di ".$durataPrestito." giorni</p>";
		echo "<p>Torna alla sezione <a href='libri.php'>libri</a>.</p>";
        //Aggiorno la variabile sessione relativa al numero di libri in prestito dell'utente.		
        $_SESSION["libri"]= (($_SESSION["libri"]) - 1);		
	}
	else echo "<p>Errore nel processo di restituzione! Riprova.</p>";
	
	}
	else echo "<p>ERRORE! Libro non presente nel database/non posseduto dall'utente</p>";
	
	//Chiudo tutto
    mysqli_stmt_free_result($stmt);
    mysqli_close($con);
}
//Se si prova a restituire più di un libro tramite URI
}else echo "<p>ERRORE! &Egrave possibile restituire solo 1 libro alla volta.";
}
}else header("Location:error.php");
?>
</div>

<!--contenitore Status -->
<div class="status">
<p class="status"><?php status() ?></p>
</div>

<!-- contenitore footer -->
<div class="footer">
<footer class="css">
<?php footer() ?>
</footer>
</div>

</div>
</body>
</html>